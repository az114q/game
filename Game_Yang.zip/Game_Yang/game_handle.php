<?php 
	
	include_once("common_SAE.php");
	
	$score = $_GET['score'];
	$openid = $_GET['openid'];
	$username = $_GET['username'];
	$headimgurl = $_GET['headimgurl'];

	// echo $username;
	// echo $headimgurl;

	$sql = "SELECT * FROM rank WHERE openid='{$openid}'";
	$res = mysql_query($sql);

	if (mysql_num_rows($res)>0) {
	 	//数据存在
	 	$row = mysql_fetch_assoc($res);

	 	if ($row['score'] < $score) {
	 		//需要更新
	 		$sql = "UPDATE rank SET score='{$score}' WHERE openid='{$openid}'";
	 		$res = mysql_query($sql);
	 		if (mysql_affected_rows()>0) {
	 			//更新成功
	 			echo '{"err":"0","mesg":"更新成功"}';
	 		}else{	 			
	 			echo '{"err":"1","mesg":"更新失败"}';
	 		}
	 	}else{
	 		//不需要更新
	 		echo '{"err":"0"}';
	 	}


	}else{
		//数据不存在
		$sql = "INSERT INTO rank(id,openid,username,headimgurl,score) VALUES (NULL,'{$openid}','{$username}','{$headimgurl}','{$score}')";
		$res = mysql_query($sql);

		if (mysql_affected_rows()>0) {
			//插入成功
			echo '{"err":"0","mesg":插入成功"}';

		}else{
			//插入失败
			echo '{"err":"1","mesg":"插入失败"}';			
		}		
	}
	





 ?>