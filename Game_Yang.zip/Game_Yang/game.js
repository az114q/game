var openid = "<?php echo $openid; ?>";
var username = "<?php echo $username; ?>";
var headimgurl = "<?php echo $headimgurl; ?>";
//选人物页面------------------------------------------------------------------
var ck=document.querySelector('.ck');
var bigpeo=document.querySelector('.ck .p1');
var go=document.querySelector('.ck .in');
var smallbtn=document.querySelectorAll('.ck .p2 .pic');
var smallTou=document.querySelectorAll('.ck .p2 .pic div');
var Num=0;
var cT=false;
for(var i=0;i<smallbtn.length;i++){
	smallbtn[i].index=i;
	smallbtn[i].ontouchstart=function(){
		event.stopPropagation();
		bigpeo.style.left=this.index*-100+"%";
		bigpeo.style.transition="left 0.5s linear";
		for(var j=0;j<smallbtn.length;j++){
			smallbtn[j].style.color="black";
			smallTou[j].style.border="";
		}
		this.style.color="red";
		smallTou[this.index].style.border="1px red solid";
		Num=this.index;
		cT=true;
	}
}
go.ontouchstart=function(){
	event.stopPropagation();
	this.src="img/enter_down.png";
	if(cT){	
		setTimeout(function(){
			go.src="img/enter_up.png";
			ck.style.display="none";
//			window.location.href="game.html";
			
		},200);
	}else{
		this.src="img/enter_up.png";
		alert("请选择人物");
	}
}
