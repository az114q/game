<?php 
	include_once("common_SAE.php");

 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Document</title>
 </head>
 <body>
 	<table border="1">
 		<tr>
 			<td>名次</td>
 			<td>头像</td>
 			<td>昵称</td>
 			<td>分数</td>
 		</tr>
		<?php 
			$sql = "SELECT * FROM rank ORDER BY score DESC LIMIT 0,10";
			$res = mysql_query($sql);
			$num = 0;

			while ($row = mysql_fetch_assoc($res)) {
				$num++;
		?>
		 	<tr>
		 		<td><?php echo $num; ?></td>
		 		<td><img src="<?php echo $row['headimgurl']; ?>"></td>
		 		<td><?php echo $row['username']; ?></td>
		 		<td><?php echo $row['score']; ?></td>
		 	</tr>
		 <?php } ?> 		
 	</table>
 </body>
 </html>