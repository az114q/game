//字体设置------------------------------------------------------------------
(function(){
	var html = document.documentElement;
	var windowWidth = html.clientWidth;
	var offsetWidth = html.offsetWidth;
	var maxWidth = Math.max(windowWidth, offsetWidth);
	if (maxWidth >= 414) { //ipad
	    maxWidth = 414;
	}
	html.style.fontSize = maxWidth / 7.5 + 'px';
	})();
	